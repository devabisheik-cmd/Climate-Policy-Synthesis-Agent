import os
from src.workflow import ClimatePolicyWorkflow

def main():
    """
    Main entry point for the Climate Policy Synthesis Agent.
    """
    # Define the user query
    user_query = "policy recommendations for reducing methane emissions in the agricultural sector for a developing nation"
    
    # Initialize and run the workflow
    workflow = ClimatePolicyWorkflow()
    final_report = workflow.run(user_query)
    
    # Output the final result
    print("\n==================================================")
    print("           FINAL POLICY SYNTHESIS REPORT          ")
    print("==================================================")
    print(final_report)
    print("==================================================")

if __name__ == "__main__":
    main()
