# 🌍 Climate Policy Synthesis Agent: A Multi-Agent System for Global Good

**Kaggle Agents Intensive Capstone Project Submission**
**Track:** Agents for Good (B)
**Project Goal:** To accelerate climate policy formulation by synthesizing complex, large-scale policy documents into concise, actionable reports tailored to specific user queries.

## 1. The Pitch: Problem, Solution, and Value (Category 1)

### Problem Statement
Policy analysts, NGOs, and journalists face a significant challenge in quickly synthesizing vast, complex, and often conflicting information from global climate reports (e.g., IPCC, national NDCs, corporate sustainability reports). The sheer volume and technical nature of these documents lead to slow, manual analysis, which delays the formulation of timely and effective climate policy.

### Solution: The Climate Policy Synthesis Agent
We have developed a **Multi-Agent System** that automates the entire policy synthesis pipeline. The system ingests a user query, intelligently extracts relevant data from a corpus of simulated policy documents, performs a critical cross-sectoral analysis, and generates a final, professional policy report.

### Core Concept & Value
The agent's value lies in its ability to handle **massive context** and **complex reasoning** through a specialized division of labor. By employing a team of four agents, the system achieves a level of depth and speed impossible for a single LLM or human analyst.

**Value Proposition:**
*   **Speed:** Reduces policy research time from weeks to minutes.
*   **Accuracy:** Cross-references information across multiple sources to identify gaps and conflicts.
*   **Actionability:** Delivers a structured report with clear, prioritized policy recommendations.

## 2. The Implementation: Architecture and Code (Category 2)

### Architecture: A Four-Agent System
The agent is built on a sequential and parallel multi-agent architecture, coordinated by an Orchestrator.

| Agent Role | Core Function | Key Concepts Applied | LLM Used |
| :--- | :--- | :--- | :--- |
| **Orchestrator Agent** | Manages the overall workflow, coordinates sub-agents, and formats the final report. | Sequential Agents, Sessions & Memory | `gemini-2.5-flash` |
| **Data Extraction Agent** | Searches for and processes relevant documents. Extracts and chunks text relevant to the query. | Parallel Agents, Tools (Custom Tool: `DocumentReaderTool`) | `gpt-4.1-mini` |
| **Policy Analysis Agent** | **Critically analyzes** the extracted data, cross-references information, and identifies policy gaps and recommendations. | **Effective Use of Gemini**, Context Engineering | `gemini-2.5-flash` |
| **Synthesis Agent** | Drafts the final policy report, including a **self-correction/evaluation loop** on the analysis before finalizing. | Agent Evaluation, Sequential Agents | `gpt-4.1-mini` |

### Key Concepts Demonstrated (Exceeding the minimum of 3)

1.  **Multi-agent system:** The four specialized agents working in concert (`src/agents.py`, `src/workflow.py`).
2.  **Sequential Agents:** The primary flow from Orchestrator -> Data Extraction -> Policy Analysis -> Synthesis is strictly sequential.
3.  **Tools (Custom Tool):** The `DocumentReaderTool` (`src/tools.py`) simulates the complex task of reading, chunking, and retrieving relevant information from a large corpus of documents, a critical function for policy analysis.
4.  **Sessions & Memory:** Simple in-memory session management is implemented via the `self.history` attribute in the `BaseAgent` class, ensuring context is maintained throughout the agent's run.
5.  **Effective Use of Gemini (Bonus):** The core reasoning and analysis is delegated to the `PolicyAnalysisAgent`, which is powered by `gemini-2.5-flash`, leveraging its superior reasoning and long-context capabilities for complex policy data.
6.  **Agent Evaluation (Bonus):** The `SynthesisAgent` includes an explicit `evaluate_and_synthesize` method that first runs a critical self-evaluation on the `PolicyAnalysisAgent`'s output before proceeding to final report generation, ensuring quality control.

## 3. Setup and Execution

### Prerequisites
*   Python 3.11+
*   An OpenAI-compatible API key (e.g., `OPENAI_API_KEY` environment variable).

### Installation
```bash
# Clone the repository (simulated)
# git clone [YOUR_REPO_URL]
cd climate_policy_agent

# Install dependencies
pip install -r requirements.txt
```

### Execution
The agent is run via the `main.py` script. The simulated policy documents are automatically created in `src/data` upon first run of the `DocumentReaderTool`.

```bash
python main.py
```

### Example Output (Simulated Run)
The agent successfully processed the query: *"policy recommendations for reducing methane emissions in the agricultural sector for a developing nation"* and produced a structured report.

**(See the full output in the Kaggle Notebook for the complete demonstration.)**

## 4. Code Structure

```
climate_policy_agent/
├── src/
│   ├── agents.py             # Defines the four agent classes (Orchestrator, Data Extraction, etc.)
│   ├── tools.py              # Defines the custom DocumentReaderTool and simulated data
│   ├── workflow.py           # Contains the main execution logic and agent coordination
│   └── data/                 # Directory for simulated policy documents
├── main.py                   # Entry point for the agent system
├── README.md                 # This document
└── requirements.txt          # Project dependencies
```

## 5. Bonus Points

*   **Effective Use of Gemini (5 Points):** The `PolicyAnalysisAgent` is explicitly powered by `gemini-2.5-flash` for the most critical, reasoning-intensive part of the workflow.
*   **Agent Evaluation (Part of Technical Implementation):** The self-correction loop in the `SynthesisAgent` demonstrates advanced agent design principles.
*   **YouTube Video Submission (10 Points):** A video will be created to articulate the problem, architecture, and a demo of the solution. (Note: This is a placeholder for the final submission package.)
