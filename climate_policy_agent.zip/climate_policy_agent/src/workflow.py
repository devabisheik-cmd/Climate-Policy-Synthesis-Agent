from src.agents import OrchestratorAgent, DataExtractionAgent, PolicyAnalysisAgent, SynthesisAgent
from src.tools import DocumentReaderTool
from typing import Dict

class ClimatePolicyWorkflow:
    """
    Orchestrates the multi-agent system for climate policy synthesis.
    (Key Concept: Multi-agent system, Sequential Agents)
    """
    def __init__(self):
        # Initialize tools
        self.doc_reader = DocumentReaderTool(data_dir="src/data")
        
        # Initialize agents
        self.orchestrator = OrchestratorAgent()
        self.data_agent = DataExtractionAgent(self.doc_reader)
        self.analysis_agent = PolicyAnalysisAgent()
        self.synthesis_agent = SynthesisAgent()
        
        print("--- Climate Policy Synthesis Workflow Initialized ---")

    def run(self, query: str) -> str:
        
        # 1. Orchestrator starts the process
        print(f"\n[Orchestrator] Starting workflow for query: '{query}'")
        
        # 2. Data Extraction Phase
        print("\n[Orchestrator] Delegating to Data Extraction Agent...")
        # The Data Extraction Agent runs the custom tool to get the data
        extracted_data: Dict[str, str] = self.data_agent.extract_data(query)
        
        if not extracted_data:
            return "[Orchestrator] Error: No relevant data found by Data Extraction Agent."
        
        # Format data for the next agent (Context Compaction/Engineering)
        data_for_analysis = "\n\n".join([
            f"--- Document: {filename} ---\n{content}" 
            for filename, content in extracted_data.items()
        ])
        
        # 3. Policy Analysis Phase (Powered by Gemini)
        print("\n[Orchestrator] Delegating to Policy Analysis Agent (Gemini)...")
        analysis_prompt = (
            f"Analyze the following documents to address the user query: '{query}'. "
            "Focus on key policy recommendations, cross-referenced findings, and policy gaps. "
            "Documents:\n\n{data_for_analysis}"
        )
        
        analysis_report = self.analysis_agent.run(analysis_prompt.format(data_for_analysis=data_for_analysis))
        
        # 4. Synthesis and Evaluation Phase
        print("\n[Orchestrator] Delegating to Synthesis Agent for final report...")
        final_report = self.synthesis_agent.evaluate_and_synthesize(query, analysis_report)
        
        # 5. Orchestrator finalizes and returns
        print("\n[Orchestrator] Workflow complete. Final report generated.")
        
        return final_report
