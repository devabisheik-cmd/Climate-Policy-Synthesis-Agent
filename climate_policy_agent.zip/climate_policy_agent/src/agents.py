import os
from openai import OpenAI
from typing import Dict, Any, List
from src.tools import DocumentReaderTool

# Initialize the OpenAI client (will use pre-configured environment variables for API key and base URL)
client = OpenAI()

# --- Agent Base Class ---

class BaseAgent:
    def __init__(self, name: str, model: str, system_prompt: str):
        self.name = name
        self.model = model
        self.system_prompt = system_prompt
        # History for session/memory management
        self.history = [{"role": "system", "content": self.system_prompt}]

    def run(self, user_prompt: str, **kwargs) -> str:
        """
        Sends a prompt to the LLM and returns the response.
        """
        # Use a temporary list for the API call to avoid polluting history with every run
        messages = self.history + [{"role": "user", "content": user_prompt}]
        
        # Simple logging for observability
        print(f"[{self.name}] Running with model: {self.model}")
        
        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                **kwargs
            )
            
            # Update history for memory/session management (simple in-memory session)
            self.history.append({"role": "user", "content": user_prompt})
            self.history.append({"role": "assistant", "content": response.choices[0].message.content})
            
            return response.choices[0].message.content
        except Exception as e:
            return f"Error in {self.name}: {e}"

# --- Specialized Agents ---

class OrchestratorAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the Orchestrator Agent. Your role is to manage the workflow for the Climate Policy Synthesis System. "
            "You will receive a user query, coordinate the Data Extraction Agent, Policy Analysis Agent, and Synthesis Agent, "
            "and finally format the output into a professional, final report."
        )
        super().__init__("Orchestrator", "gemini-2.5-flash", system_prompt)

class DataExtractionAgent(BaseAgent):
    def __init__(self, doc_reader: DocumentReaderTool):
        system_prompt = (
            "You are the Data Extraction Agent. Your sole purpose is to identify relevant documents and extract the text "
            "using the provided DocumentReaderTool. Do not perform any analysis. "
            "Your output must be a dictionary of file names and their content."
        )
        super().__init__("DataExtraction", "gpt-4.1-mini", system_prompt)
        self.doc_reader = doc_reader
        
    def extract_data(self, query: str) -> Dict[str, str]:
        """
        Uses the DocumentReaderTool to find and retrieve relevant document chunks.
        (Key Concept: Tools - Custom Tool)
        """
        relevant_files = self.doc_reader.search_relevant_chunks(query)
        extracted_data = self.doc_reader.get_all_data(relevant_files)
        return extracted_data

class PolicyAnalysisAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the Policy Analysis Agent, powered by Gemini. Your task is to critically analyze the provided document chunks. "
            "You must identify key policy recommendations, cross-reference information, and pinpoint any policy gaps or conflicts. "
            "Your output must be a structured analysis, not the final report. Use clear headings for 'Key Recommendations', 'Cross-Referenced Findings', and 'Policy Gaps'."
        )
        # Using the stronger Gemini model for the core reasoning task (Bonus Point: Effective Use of Gemini)
        super().__init__("PolicyAnalysis", "gemini-2.5-flash", system_prompt)

class SynthesisAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the Synthesis Agent. Your role is to take the structured analysis from the Policy Analysis Agent, "
            "evaluate its quality, and then transform it into a final, professional, and concise policy report. "
            "The report must be clear, actionable, and directly address the original user query."
        )
        super().__init__("Synthesis", "gpt-4.1-mini", system_prompt)

    def evaluate_and_synthesize(self, original_query: str, analysis_report: str) -> str:
        """
        Performs a self-correction/evaluation step before final synthesis.
        (Key Concept: Agent Evaluation)
        """
        # Step 1: Agent Evaluation (Self-Correction)
        evaluation_prompt = (
            f"Critically evaluate the following policy analysis report based on the original query: '{original_query}'. "
            "Check for clarity, completeness, and direct relevance to the query. "
            "If the analysis is lacking, suggest specific improvements. "
            "Analysis Report:\n---\n{analysis_report}\n---"
            "Your evaluation should be brief, focusing only on whether the analysis is sufficient for a final report. "
            "Respond with 'SUFFICIENT' if the analysis is good, or a brief critique if it is not."
        )
        
        evaluation_result = self.run(evaluation_prompt.format(analysis_report=analysis_report))
        
        print(f"[Synthesis] Evaluation Result: {evaluation_result}")
        
        # Step 2: Synthesis
        synthesis_prompt = (
            f"Based on the following analysis and the original query: '{original_query}', "
            "write a final, professional policy report. The report must be structured with: "
            "1. Executive Summary (1-2 sentences). "
            "2. Key Findings. "
            "3. Policy Recommendations. "
            "4. Identified Policy Gaps. "
            "Ensure the tone is professional and the content is concise and actionable. "
            "Analysis Report:\n---\n{analysis_report}\n---"
        )
        
        final_report = self.run(synthesis_prompt)
        
        return final_report
