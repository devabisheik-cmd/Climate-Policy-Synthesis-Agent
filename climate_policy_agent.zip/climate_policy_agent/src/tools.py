import os
from typing import List, Dict

# --- Custom Tool Implementation ---

class DocumentReaderTool:
    """
    A custom tool to simulate reading and chunking large policy documents.
    In a real-world scenario, this would involve parsing PDFs, extracting text,
    and intelligently chunking the content.
    """
    def __init__(self, data_dir: str = "src/data"):
        self.data_dir = data_dir
        self._initialize_simulated_data()

    def _initialize_simulated_data(self):
        """
        Creates simulated policy document chunks for demonstration.
        """
        # Simulated data for a query about "methane emissions in agriculture"
        
        # Chunk 1: IPCC Report Summary on Agriculture
        ipcc_text = (
            "IPCC AR6 WGIII Summary: Agriculture, Forestry and Other Land Use (AFOLU) "
            "accounts for about 13% of global greenhouse gas emissions. Methane (CH4) "
            "from livestock (enteric fermentation) and rice cultivation is a major contributor. "
            "Mitigation potential is high through dietary shifts, improved livestock management, "
            "and water management in rice paddies. Policy recommendation: Implement carbon pricing "
            "mechanisms on high-methane-intensity agricultural products."
        )
        with open(os.path.join(self.data_dir, "ipcc_chunk_1.txt"), "w") as f:
            f.write(ipcc_text)

        # Chunk 2: National Determined Contribution (NDC) for a Developing Nation
        ndc_text = (
            "Nation X NDC (2025 Update): Our primary focus for emission reduction is the energy sector. "
            "However, we commit to a voluntary 10% reduction in agricultural methane emissions by 2035 "
            "through a national program to distribute feed additives to smallholder farmers. "
            "Current policy gap: Lack of funding for research into local, low-cost feed additives."
        )
        with open(os.path.join(self.data_dir, "ndc_chunk_2.txt"), "w") as f:
            f.write(ndc_text)

        # Chunk 3: Corporate Sustainability Report (Irrelevant)
        corp_text = (
            "TechCorp 2024 Sustainability Report: We achieved 100% renewable energy for our data centers. "
            "Our focus is on Scope 2 emissions. We have no direct agricultural operations."
        )
        with open(os.path.join(self.data_dir, "corp_chunk_3.txt"), "w") as f:
            f.write(corp_text)

    def read_document_chunk(self, filename: str) -> str:
        """
        Reads a specific document chunk.
        """
        path = os.path.join(self.data_dir, filename)
        if not os.path.exists(path):
            return f"Error: Document chunk '{filename}' not found."
        with open(path, "r") as f:
            return f.read()

    def search_relevant_chunks(self, query: str) -> List[str]:
        """
        Simulates searching a document database for relevant chunks based on a query.
        For this demo, it uses simple keyword matching.
        """
        print(f"--- DocumentReaderTool: Searching for chunks relevant to: '{query}' ---")
        
        all_chunks = [f for f in os.listdir(self.data_dir) if f.endswith(".txt")]
        relevant_files = []
        
        # Simple keyword matching simulation
        keywords = ["methane", "agriculture", "policy", "NDC", "IPCC"]
        if any(k in query.lower() for k in keywords):
            # Simulate finding the relevant files
            relevant_files = ["ipcc_chunk_1.txt", "ndc_chunk_2.txt"]
        
        print(f"--- DocumentReaderTool: Found relevant chunks: {relevant_files} ---")
        return relevant_files

    def get_all_data(self, relevant_files: List[str]) -> Dict[str, str]:
        """
        Reads the content of all relevant files.
        """
        data = {}
        for filename in relevant_files:
            data[filename] = self.read_document_chunk(filename)
        return data

# Example usage (for testing)
if __name__ == "__main__":
    tool = DocumentReaderTool(data_dir="./data")
    query = "policy recommendations for reducing methane emissions in the agricultural sector"
    files = tool.search_relevant_chunks(query)
    data = tool.get_all_data(files)
    print("\n--- Extracted Data ---")
    for filename, content in data.items():
        print(f"File: {filename}\nContent: {content[:100]}...\n")
