# Climate Policy Synthesis Agent: Architecture and Implementation Plan

**Project Track:** Agents for Good
**Project Goal:** To create a multi-agent system that synthesizes complex, large-scale climate policy documents into concise, actionable reports tailored to a specific user query.

## 1. Agent Architecture (Multi-Agent System)

The system will employ a sequential and parallel multi-agent architecture, consisting of three specialized agents coordinated by an Orchestrator.

| Agent Role | Core Function | Key Concepts Applied | LLM Used |
| :--- | :--- | :--- | :--- |
| **1. Orchestrator Agent** | Receives user query, manages the overall workflow, coordinates sub-agents, and formats the final report. | Sequential Agents, Sessions & Memory (InMemorySessionService) | `gemini-2.5-flash` |
| **2. Data Extraction Agent** | Searches for and processes relevant documents (e.g., IPCC, NDCs). Extracts and chunks text relevant to the query. | Parallel Agents, Tools (Google Search, Custom Tool: `DocumentReaderTool`) | `gpt-4.1-mini` |
| **3. Policy Analysis Agent** | Analyzes the extracted data chunks, cross-references information, and identifies policy gaps and recommendations. This is the core reasoning agent. | Effective Use of Gemini, Context Engineering (Context Compaction) | `gemini-2.5-flash` |
| **4. Synthesis Agent** | Takes the analysis from the Policy Analysis Agent and drafts a coherent, well-structured policy report. It includes a self-correction loop. | Agent Evaluation, Sequential Agents | `gpt-4.1-mini` |

## 2. Implementation Details and Key Concepts

The project will be implemented in Python, utilizing a suitable agent framework (e.g., LangChain, CrewAI, or a custom implementation using the OpenAI/Gemini SDKs). Given the sandbox environment, a custom, lightweight implementation focusing on clear demonstration of the concepts is preferred.

### Key Concepts to be Demonstrated (Minimum 5)

1.  **Multi-agent system:** The four-agent structure (Orchestrator, Data Extraction, Policy Analysis, Synthesis).
2.  **Sequential and Parallel Agents:** Orchestrator runs sequentially; Data Extraction Agent can run search and document reading in parallel.
3.  **Tools:**
    *   **Built-in Tool:** Google Search for real-time data and document links.
    *   **Custom Tool:** `DocumentReaderTool` (simulates reading and chunking large documents from a local corpus).
4.  **Sessions & Memory:** `InMemorySessionService` for managing the conversation state and the flow of information (extracted data, analysis) between agents.
5.  **Effective Use of Gemini:** The core Policy Analysis Agent will be powered by `gemini-2.5-flash` for its advanced reasoning capabilities on complex policy data.
6.  **Agent Evaluation:** The Synthesis Agent will contain a prompt to critically review the Policy Analysis Agent's output for coherence, completeness, and factual grounding before finalizing the report.

## 3. File Structure

```
climate_policy_agent/
├── src/
│   ├── __init__.py
│   ├── agents.py             # Defines the four agent classes (Orchestrator, Data Extraction, etc.)
│   ├── tools.py              # Defines the custom DocumentReaderTool
│   ├── workflow.py           # Contains the main execution logic and agent coordination
│   └── data/                 # Directory for simulated policy documents (e.g., text files)
│       ├── ipcc_report_chunk_1.txt
│       └── ndc_policy_summary.txt
├── main.py                   # Entry point for the agent system
├── architecture_plan.md      # This document
├── README.md                 # Project documentation (for GitHub/Kaggle)
└── requirements.txt          # Project dependencies
```

## 4. Development Plan

1.  **Setup:** Create file structure and `requirements.txt`.
2.  **Tool Development:** Implement the `DocumentReaderTool` (simulating document reading and chunking).
3.  **Agent Development (Bottom-Up):**
    *   Implement the **Data Extraction Agent** with tool use.
    *   Implement the **Policy Analysis Agent** with a focus on prompt engineering for complex reasoning.
    *   Implement the **Synthesis Agent** with the self-evaluation logic.
    *   Implement the **Orchestrator Agent** to tie the flow together.
4.  **Workflow Integration:** Write `workflow.py` and `main.py` to demonstrate the full execution flow.
5.  **Documentation:** Write the comprehensive `README.md` and prepare the Kaggle Notebook content.
6.  **Testing:** Run the agent with a sample query and validate the output against the simulated data.
